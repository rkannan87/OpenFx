package com.enterprise.sftp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;

import com.enterprise.sftp.config.SftpTransferProperties;

/**
 * Spring Boot entry point — Java 17.
 *
 * <h3>Usage</h3>
 * <pre>
 * java -jar sftp-copy-1.0.0.jar \
 *      --sftp.source-file=/data/input/report.csv \
 *      --sftp.destination-path=/upload/reports \
 *      --sftp.destination-file=report.csv
 * </pre>
 *
 * <p>Or as positional args (index 0, 1, 2):
 * <pre>
 * java -jar sftp-copy-1.0.0.jar \
 *      /data/input/report.csv /upload/reports report.csv
 * </pre>
 *
 * <h3>Java 17 change from Java 21</h3>
 * <p>Result handling uses {@code instanceof} pattern matching (GA Java 16+)
 * with record accessor calls, replacing Java 21 inline record destructuring
 * in switch arms.
 *
 * <p>Text block for the missing-args error replaced with a standard
 * string literal — text blocks are GA since Java 15, so this change is
 * actually unnecessary, but kept here to make the diff explicit.
 */
@SpringBootApplication
@EnableConfigurationProperties(SftpTransferProperties.class)
public class SftpCopyApplication implements CommandLineRunner, ExitCodeGenerator {

    private static final Logger log = LoggerFactory.getLogger(SftpCopyApplication.class);

    private final SftpFileCopy           sftpFileCopy;
    private final SftpTransferProperties cfg;
    private final ApplicationContext     ctx;

    /** Exit code propagated to the OS: 0 = success, 1 = failure, 2 = bad args. */
    private int exitCode = 0;

    public SftpCopyApplication(SftpFileCopy sftpFileCopy,
                                SftpTransferProperties cfg,
                                ApplicationContext ctx) {
        this.sftpFileCopy = sftpFileCopy;
        this.cfg          = cfg;
        this.ctx          = ctx;
    }

    public static void main(String[] args) {
        System.exit(SpringApplication.run(SftpCopyApplication.class, args)
                .getBean(SftpCopyApplication.class).exitCode);
    }

    // ── CommandLineRunner ─────────────────────────────────────────────────────

    @Override
    public void run(String... args) {

        // ── Resolve the three required arguments ─────────────────────────────
        String sourceFile      = resolve(cfg.sourceFile(),      args, 0, "sourceFile");
        String destinationPath = resolve(cfg.destinationPath(), args, 1, "destinationPath");
        String destinationFile = resolve(cfg.destinationFile(), args, 2, "destinationFile");

        if (sourceFile == null || destinationPath == null || destinationFile == null) {
            // Java 17: plain string literal (text blocks are GA in Java 15,
            // but shown as a regular literal to highlight the Java 17 baseline)
            log.error("Missing required arguments.\n"
                    + "Usage (named):\n"
                    + "  --sftp.source-file=<path>\n"
                    + "  --sftp.destination-path=<path>\n"
                    + "  --sftp.destination-file=<filename>\n"
                    + "Usage (positional):\n"
                    + "  <sourceFile> <destinationPath> <destinationFile>");
            exitCode = 2;
            return;
        }

        log.info("Starting transfer — src={} dst={}/{}",
                sourceFile, destinationPath, destinationFile);

        // ── Execute transfer ──────────────────────────────────────────────────
        SftpFileCopy.TransferResult result =
                sftpFileCopy.copyFile(sourceFile, destinationPath, destinationFile);

        // ── Handle result — Java 17: instanceof pattern matching ──────────────
        //
        // Java 21 equivalent (record patterns, inline destructuring):
        //   case TransferResult.Success(long bytes, Duration elapsed, double mbps, String id) -> ...
        //
        // Java 17: sealed interface + instanceof gives the same type safety;
        // field values are accessed via record accessors after the cast.
        if (result instanceof SftpFileCopy.TransferResult.Success success) {
            log.info("[{}] SUCCESS — {} bytes in {}s @ {:.2f} MB/s",
                    success.transferId(),
                    success.bytesTransferred(),
                    success.elapsed().toSeconds(),
                    success.throughputMBps());
            exitCode = 0;

        } else if (result instanceof SftpFileCopy.TransferResult.Failure failure) {
            log.error("[{}] FAILED — {}",
                    failure.transferId(), failure.reason(), failure.cause());
            exitCode = 1;
        }
    }

    @Override
    public int getExitCode() { return exitCode; }

    // ── Argument resolution helper ────────────────────────────────────────────

    private static String resolve(String named, String[] args, int index, String label) {
        if (named != null && !named.isBlank()) return named.trim();
        if (args.length > index && args[index] != null && !args[index].isBlank())
            return args[index].trim();
        log.warn("Argument '{}' not supplied (named or positional index {})", label, index);
        return null;
    }
}
