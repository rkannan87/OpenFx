package com.enterprise.sftp.config;

import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.Semaphore;

/**
 * Provides a bounded pool of authenticated {@link SSHClient} instances.
 *
 * <p>Pool size = {@code sftp.ssh-pool-size} (application.yml).
 *
 * <p><b>Java 17 coupling note:</b> the fixed thread pool in
 * {@link com.enterprise.sftp.SftpFileCopy} is sized to {@code sshPoolSize}.
 * Both values must be equal: if the thread pool were larger, threads would
 * block waiting for SSH clients; if smaller, SSH clients would go unused.
 * Java 21 virtual threads eliminate this coupling entirely.
 */
@Configuration
public class SftpConnectionConfig {

    private static final Logger log = LoggerFactory.getLogger(SftpConnectionConfig.class);

    @Bean
    public PooledSshClient pooledSshClient(SftpTransferProperties cfg) throws IOException {
        return new PooledSshClient(cfg);
    }

    // ── Pool implementation ───────────────────────────────────────────────────

    public static final class PooledSshClient {

        private final SftpTransferProperties cfg;
        private final Deque<SSHClient>        idle       = new ArrayDeque<>();
        private final Semaphore               semaphore;
        private final List<SSHClient>         allClients = new ArrayList<>();
        private       long                    uploadCount = 0;

        public PooledSshClient(SftpTransferProperties cfg) throws IOException {
            this.cfg       = cfg;
            this.semaphore = new Semaphore(cfg.sshPoolSize(), true);

            log.info("SSH pool: connecting {} clients to {}:{}",
                    cfg.sshPoolSize(), cfg.host(), cfg.port());

            for (int i = 0; i < cfg.sshPoolSize(); i++) {
                SSHClient client = buildClient();
                idle.addLast(client);
                allClients.add(client);
            }
            log.info("SSH pool ready — {} connections", cfg.sshPoolSize());
        }

        // ── Borrow / return ───────────────────────────────────────────────────

        public SSHClient borrowClient() throws InterruptedException {
            semaphore.acquire();
            synchronized (idle) {
                return idle.removeFirst();
            }
        }

        public void returnClient(SSHClient client) {
            synchronized (idle) {
                idle.addLast(client);
            }
            semaphore.release();
        }

        public synchronized void incrementUploadCount() { uploadCount++; }

        public synchronized long uploadCount() { return uploadCount; }

        // ── Lifecycle ─────────────────────────────────────────────────────────

        @jakarta.annotation.PreDestroy
        public void close() {
            log.info("SSH pool: closing {} connections (uploads={})",
                    allClients.size(), uploadCount);
            for (SSHClient c : allClients) {
                try { c.disconnect(); } catch (Exception ignored) {}
            }
        }

        // ── SSH client factory ────────────────────────────────────────────────

        private SSHClient buildClient() throws IOException {
            SSHClient client = new SSHClient();
            client.addHostKeyVerifier(resolveHostKeyVerifier());
            client.connect(cfg.host(), cfg.port());
            authenticate(client);
            return client;
        }

        private net.schmizz.sshj.transport.verification.HostKeyVerifier
                resolveHostKeyVerifier() throws IOException {
            if (cfg.knownHostsPath() == null || cfg.knownHostsPath().isBlank()
                    || "/dev/null".equals(cfg.knownHostsPath())) {
                log.warn("Host key verification DISABLED — not suitable for production");
                return new PromiscuousVerifier();
            }
            SSHClient tmp = new SSHClient();
            tmp.loadKnownHosts(new java.io.File(cfg.knownHostsPath()));
            return (hostname, port, key) -> {
                try { tmp.addHostKeyVerifier(cfg.knownHostsPath()); } catch (Exception ignored) {}
                return true;
            };
        }

        private void authenticate(SSHClient client) throws IOException {
            if (cfg.privateKeyPath() != null && !cfg.privateKeyPath().isBlank()) {
                client.authPublickey(cfg.username(), cfg.privateKeyPath());
            } else {
                client.authPassword(cfg.username(), cfg.password());
            }
        }
    }
}
