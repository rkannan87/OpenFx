package com.enterprise.sftp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * All tuning parameters loaded from {@code application.yml} under the
 * {@code sftp} prefix.
 *
 * <p>Records are GA since Java 16 — no change needed from the Java 21 version.
 *
 * <p>Example override at runtime:
 * <pre>
 *   --sftp.host=sftp.example.com
 *   --sftp.source-file=/data/report.csv
 * </pre>
 */
@ConfigurationProperties(prefix = "sftp")
public record SftpTransferProperties(

        // ── Connection ────────────────────────────────────────────────────────
        String  host,
        int     port,
        String  username,

        /** Path to private key file (PEM). Mutually exclusive with {@code password}. */
        String  privateKeyPath,
        String  password,

        /** Known-hosts file; set to {@code /dev/null} to disable strict checking (non-prod). */
        String  knownHostsPath,

        // ── Transfer control ──────────────────────────────────────────────────
        boolean enabled,

        /** Files larger than this threshold are split into parallel chunks. */
        long    chunkThresholdBytes,

        /** Size of each parallel chunk in bytes (default 64 MB). */
        long    chunkSizeBytes,

        /** Read/write buffer size per stream in bytes (default 8 KB). */
        int     bufferSizeBytes,

        /**
         * SSH connection pool size.
         *
         * <p><b>Java 17 note:</b> this value also sets the fixed thread-pool size
         * in {@code SftpFileCopy}.  Pool size must equal SSH pool size to ensure
         * every platform thread can always acquire an SSH client without deadlocking.
         * (Java 21 removes this coupling via virtual threads.)
         */
        int     sshPoolSize,

        /** Per-chunk timeout in minutes; total deadline = this × chunkCount. */
        int     timeoutPerChunkMinutes,

        /** Minutes to wait for in-flight transfers on graceful shutdown. */
        int     executorShutdownTimeoutMinutes,

        // ── CLI arguments (named flag path) ──────────────────────────────────
        String  sourceFile,
        String  destinationPath,
        String  destinationFile

) {
    // ── Derived helpers ───────────────────────────────────────────────────────

    /** {@code true} when file exceeds the chunk threshold. */
    public boolean requiresChunkedTransfer(long fileSize) {
        return fileSize > chunkThresholdBytes;
    }

    /** Number of chunks for a given file size. */
    public int chunkCount(long fileSize) {
        return (int) Math.ceil((double) fileSize / chunkSizeBytes);
    }

    /**
     * Length of chunk {@code index}.
     * The last chunk may be shorter than {@code chunkSizeBytes}.
     */
    public long chunkLength(int index, int totalChunks, long fileSize) {
        return (index == totalChunks - 1)
                ? fileSize - ((long) index * chunkSizeBytes)
                : chunkSizeBytes;
    }
}
