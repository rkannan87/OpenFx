package com.enterprise.sftp;

import com.enterprise.sftp.SftpFileCopy.TransferResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Verifies argument wiring and result-handling without a live SFTP server.
 * {@link SftpFileCopy} is mocked — no SSH connection is attempted.
 */
@SpringBootTest(
        properties = {
                "sftp.enabled=true",
                "sftp.host=localhost",
                "sftp.port=22",
                "sftp.username=test",
                "sftp.known-hosts-path=/dev/null",
                "sftp.ssh-pool-size=1",
                "sftp.chunk-size-bytes=67108864",
                "sftp.chunk-threshold-bytes=134217728",
                "sftp.buffer-size-bytes=8192",
                "sftp.timeout-per-chunk-minutes=10",
                "sftp.executor-shutdown-timeout-minutes=5"
        }
)
class SftpCopyApplicationTest {

    @MockBean
    SftpFileCopy sftpFileCopy;

    @Autowired
    SftpCopyApplication app;

    @Test
    void successResult_setsExitCodeZero() {
        when(sftpFileCopy.copyFile("/src/file.txt", "/dst", "file.txt"))
                .thenReturn(new TransferResult.Success(
                        1024L, Duration.ofMillis(50), 20.0, "test-id"));

        app.run("/src/file.txt", "/dst", "file.txt");

        assertThat(app.getExitCode()).isZero();
    }

    @Test
    void failureResult_setsExitCodeOne() {
        when(sftpFileCopy.copyFile("/src/file.txt", "/dst", "file.txt"))
                .thenReturn(new TransferResult.Failure(
                        "SFTP error", new RuntimeException("refused"), "test-id"));

        app.run("/src/file.txt", "/dst", "file.txt");

        assertThat(app.getExitCode()).isEqualTo(1);
    }

    @Test
    void missingArgs_setsExitCodeTwo() {
        app.run();   // no args
        assertThat(app.getExitCode()).isEqualTo(2);
    }
}
