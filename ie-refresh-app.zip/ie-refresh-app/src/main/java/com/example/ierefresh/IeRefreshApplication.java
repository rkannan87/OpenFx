package com.example.ierefresh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class IeRefreshApplication {

    public static void main(String[] args) {
        SpringApplication.run(IeRefreshApplication.class, args);
    }
}
