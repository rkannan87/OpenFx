package com.example.ierefresh;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class IeRefreshApplication {

    public static void main(String[] args) {
        // Spring Boot sets java.awt.headless=true by default, which breaks
        // java.awt.Robot (needed to move focus / send F5). Force it off.
        System.setProperty("java.awt.headless", "false");

        new SpringApplicationBuilder(IeRefreshApplication.class)
                .headless(false)
                .run(args);
    }
}
