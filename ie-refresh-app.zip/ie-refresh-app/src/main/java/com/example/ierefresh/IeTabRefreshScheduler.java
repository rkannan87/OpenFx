package com.example.ierefresh;

import com.sun.jna.Native;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef.HWND;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Finds an Internet Explorer window by a substring in its title bar,
 * brings it to the foreground, and sends F5 to refresh it.
 *
 * LIMITATION: classic IE windows only show a title for the currently
 * ACTIVE tab, so F5 refreshes whichever tab is focused in that window
 * at run time — it cannot target a specific background tab.
 *
 * Windows only (uses User32 via JNA).
 */
@Component
public class IeTabRefreshScheduler {

    // Substring to match in the IE window title bar
    @Value("${ie.refresh.title-substring:YourTabTitleHere}")
    private String targetTitleSubstring;

    private Robot robot;

    private Robot robot() throws AWTException {
        if (robot == null) {
            robot = new Robot();
        }
        return robot;
    }

    // Runs every 15 minutes (15 * 60 * 1000 ms). Configurable via ie.refresh.interval-ms.
    @Scheduled(fixedRateString = "${ie.refresh.interval-ms:900000}")
    public void refreshIeTab() {
        HWND hwnd = findWindowByTitleSubstring(targetTitleSubstring);

        if (hwnd == null) {
            System.out.println("No matching IE window found for \"" + targetTitleSubstring + "\". Skipping.");
            return;
        }

        boolean brought = User32.INSTANCE.SetForegroundWindow(hwnd);
        if (!brought) {
            System.out.println("Found window but could not bring it to foreground.");
        }

        try {
            Thread.sleep(300); // let the window gain focus before sending the key
            Robot r = robot();
            r.keyPress(KeyEvent.VK_F5);
            r.keyRelease(KeyEvent.VK_F5);
            System.out.println("F5 sent to IE window matching \"" + targetTitleSubstring + "\".");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (AWTException e) {
            System.err.println("Unable to initialize Robot: " + e.getMessage());
        }
    }

    private HWND findWindowByTitleSubstring(String substring) {
        AtomicReference<HWND> found = new AtomicReference<>();
        String needle = substring.toLowerCase();

        User32.INSTANCE.EnumWindows((hWnd, data) -> {
            char[] buffer = new char[1024];
            User32.INSTANCE.GetWindowText(hWnd, buffer, buffer.length);
            String title = Native.toString(buffer);

            if (!title.isEmpty() && title.toLowerCase().contains(needle)) {
                found.set(hWnd);
                return false; // stop enumeration
            }
            return true;
        }, null);

        return found.get();
    }
}
